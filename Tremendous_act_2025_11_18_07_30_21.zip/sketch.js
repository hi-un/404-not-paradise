let video, poseNet, handpose;
let poses = [], hands = [];
let poseNetReady = false, handposeReady = false;
let personDetected = false;

let score = 0;
let trashItems = [];
let trashBin = { x: 540, y: 100, w: 80, h: 100 };
let holdingTrash = null;
let isGrabbing = false;
let handPosition = { x: 0, y: 0 };

// 이미지 저장 
let trashImages = {};
let imageBin;  

// 게임 상태 관리
let gameState = 'PLAYING'; // 'PLAYING', 'GAMEOVER', 'RANKING'
let gameTime = 60; // 60초 게임
let startTime;
let remainingTime = gameTime;

// 랭킹 시스템
let rankings = [];
let maxRankings = 10;
let playerName = '';
let isEnteringName = false;

const trashTypes = [
  { 
    name: '페트병', 
    points: 10, 
    color: [100, 200, 255],
    imageUrl: null
  },
  { 
    name: '캔', 
    points: 15, 
    color: [200, 200, 200],
    imageUrl: null
  },
  { 
    name: '종이', 
    points: 5, 
    color: [255, 255, 200],
    imageUrl: null
  },
  { 
    name: '음식물', 
    points: 8, 
    color: [255, 200, 100],
    imageUrl: null
  },
  { 
    name: '병', 
    points: 12, 
    color: [150, 255, 150],
    imageUrl: null
  }
];

let successEffectTimer = 0;
let successParticles = [];
  
function preload() {
  // 로컬 스토리지에서 랭킹 불러오기
  loadRankings();
}

function setup() {
  let canvas = createCanvas(640, 480);
  canvas.parent('canvas-container');
  
  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();
  
  poseNet = ml5.poseNet(video, onPoseNetReady);
  poseNet.on('pose', onPoseResults);
  
  handpose = ml5.handpose(video, onHandposeReady);
  handpose.on('hand', onHandResults);
  
  for (let i = 0; i < 5; i++) {
    spawnTrash();
  }
  
  // 게임 시작 시간 설정
  startTime = millis();
  
  // 초기 배경 설정
  document.body.className = 'bg-notclean';
}

function draw() {
  // 게임 상태에 따른 처리
  if (gameState === 'PLAYING') {
    drawGame();
  } else if (gameState === 'GAMEOVER') {
    drawGameOver();
  } else if (gameState === 'RANKING') {
    drawRankingScreen();
  }
}

function drawGame() {
  // 남은 시간 계산
  let elapsedTime = (millis() - startTime) / 1000;
  remainingTime = max(0, gameTime - elapsedTime);
  
  // 시간이 다 되면 게임 종료
  if (remainingTime <= 0) {
    endGame();
    return;
  }
  
  // body의 배경 이미지를 동적으로 변경
  if (holdingTrash) {
    document.body.className = 'bg-clean';
  } else {
    document.body.className = 'bg-notclean';
  }
  
  // 캔버스는 투명하게 지우기
  clear();
  
  // 카메라 비디오는 불투명하게 표시
  push();
  translate(width, 0);
  scale(-1, 1);
  image(video, 0, 0, width, height);
  pop();
  
  if (!poseNetReady || !handposeReady) {
    fill(0, 0, 0, 150);
    rect(0, 0, width, height);
    fill(255);
    textSize(30);
    textAlign(CENTER, CENTER);
    text('모델 로딩 중...', width/2, height/2);
    return;
  }
  
  checkPersonDetection();
  
  if (personDetected) {
    drawTrash();
    drawTrashBin();
    drawHands();
    detectGrabAction();
    displayScore();
    displayTimer();
    displayInstructions();
  } else {
    fill(0, 0, 0, 100);
    rect(0, 0, width, height);
    fill(255);
    textSize(40);
    textAlign(CENTER, CENTER);
    text('사람을 인식해주세요', width/2, height/2);
  }
  
  displayDebugInfo();
}

function drawGameOver() {
  clear();
  
  // 반투명 배경
  fill(0, 0, 0, 200);
  rect(0, 0, width, height);
  
  // 게임 오버 타이틀
  fill(255, 215, 0);
  stroke(255);
  strokeWeight(4);
  textSize(60);
  textAlign(CENTER, CENTER);
  text('게임 종료!', width/2, 100);
  
  // 최종 점수
  fill(255);
  noStroke();
  textSize(40);
  text('최종 점수', width/2, 180);
  
  fill(255, 165, 0);
  stroke(255, 255, 0);
  strokeWeight(3);
  textSize(80);
  text(score, width/2, 250);
  
  // 랭킹 진입 여부 확인
  let isTopRank = checkTopRank(score);
  
  if (isTopRank && !isEnteringName) {
    fill(0, 255, 0);
    textSize(25);
    noStroke();
    text('🎉 축하합니다! 상위 랭킹에 진입했습니다! 🎉', width/2, 340);
    
    fill(255);
    textSize(20);
    text('이름을 입력하고 Enter를 눌러주세요', width/2, 380);
    
    // 입력창 표시
    fill(255, 255, 255, 230);
    stroke(255, 200, 0);
    strokeWeight(3);
    rect(width/2 - 150, 400, 300, 50, 10);
    
    fill(0);
    noStroke();
    textSize(25);
    text(playerName + '|', width/2, 427);
  } else if (isEnteringName) {
    fill(255);
    textSize(20);
    noStroke();
    text('이름이 저장되었습니다!', width/2, 340);
  } else {
    fill(255);
    textSize(20);
    noStroke();
    text('랭킹 진입에 실패했습니다', width/2, 340);
  }
  
  // 안내 메시지
  fill(255, 255, 255, 200);
  textSize(18);
  
  if (isTopRank && !isEnteringName) {
    // 이름 입력 중에는 단축키 안내 표시 안함
    text('이름 입력 후 Enter를 눌러주세요', width/2, height - 30);
  } else {
    // 이름 입력이 끝났거나 랭킹 진입 실패
    text('R 키: 다시 시작 | L 키: 랭킹 보기', width/2, height - 30);
  }
}

function drawRankingScreen() {
  clear();
  
  // 배경
  fill(0, 0, 0, 220);
  rect(0, 0, width, height);
  
  // 타이틀
  fill(255, 215, 0);
  stroke(255);
  strokeWeight(4);
  textSize(50);
  textAlign(CENTER, CENTER);
  text('🏆 명예의 전당 🏆', width/2, 50);
  
  // 랭킹 표시
  fill(255);
  noStroke();
  textSize(16);
  textAlign(LEFT, TOP);
  
  let startY = 120;
  let lineHeight = 32;
  
  // 헤더
  fill(255, 215, 0);
  textSize(18);
  text('순위', 80, startY - 35);
  text('이름', 180, startY - 35);
  text('점수', 420, startY - 35);
  text('날짜', 500, startY - 35);
  
  // 구분선
  stroke(255, 215, 0);
  strokeWeight(2);
  line(60, startY - 15, width - 60, startY - 15);
  
  // 랭킹 목록
  noStroke();
  for (let i = 0; i < rankings.length; i++) {
    let rank = rankings[i];
    let y = startY + i * lineHeight;
    
    // 순위에 따른 색상
    if (i === 0) {
      fill(255, 215, 0); // 금색
    } else if (i === 1) {
      fill(192, 192, 192); // 은색
    } else if (i === 2) {
      fill(205, 127, 50); // 동색
    } else {
      fill(255);
    }
    
    textSize(20);
    textAlign(CENTER, TOP);
    text(i + 1, 100, y);
    
    textAlign(LEFT, TOP);
    textSize(18);
    text(rank.name, 180, y);
    
    fill(255, 165, 0);
    text(rank.score, 420, y);
    
    fill(200);
    textSize(14);
    text(rank.date, 500, y + 3);
  }
  
  // 랭킹이 없을 때
  if (rankings.length === 0) {
    fill(255);
    textSize(25);
    textAlign(CENTER, CENTER);
    text('아직 등록된 기록이 없습니다', width/2, height/2);
  }
  
  // 안내 메시지
  fill(255, 255, 255, 200);
  textSize(18);
  textAlign(CENTER, BOTTOM);
  text('R 키: 다시 시작 | ESC 키: 게임으로 돌아가기', width/2, height - 30);
}

function endGame() {
  gameState = 'GAMEOVER';
  playerName = '';
  isEnteringName = false;
}

function restartGame() {
  gameState = 'PLAYING';
  score = 0;
  trashItems = [];
  holdingTrash = null;
  isGrabbing = false;
  startTime = millis();
  remainingTime = gameTime;
  playerName = '';
  isEnteringName = false;
  
  // 쓰레기 다시 생성
  for (let i = 0; i < 5; i++) {
    spawnTrash();
  }
  
  document.body.className = 'bg-notclean';
}

function checkTopRank(newScore) {
  // 랭킹이 10개 미만이면 무조건 진입
  if (rankings.length < maxRankings) {
    return true;
  }
  
  // 최하위 점수보다 높으면 진입
  return newScore > rankings[rankings.length - 1].score;
}

function saveScore() {
  // 이름이 비어있으면 저장하지 않음
  if (playerName.trim() === '') {
    return;
  }
  
  let newRank = {
    name: playerName.trim(),
    score: score,
    date: getFormattedDate()
  };
  
  rankings.push(newRank);
  
  // 점수 순으로 정렬 (높은 점수가 위로)
  rankings.sort((a, b) => b.score - a.score);
  
  // 상위 10개만 유지
  rankings = rankings.slice(0, maxRankings);
  
  // 로컬 스토리지에 저장
  saveRankings();
  
  isEnteringName = true;
}

function loadRankings() {
  let saved = localStorage.getItem('trashGameRankings');
  if (saved) {
    rankings = JSON.parse(saved);
  }
}

function saveRankings() {
  localStorage.setItem('trashGameRankings', JSON.stringify(rankings));
}

function getFormattedDate() {
  let now = new Date();
  let month = String(now.getMonth() + 1).padStart(2, '0');
  let day = String(now.getDate()).padStart(2, '0');
  return `${month}/${day}`;
}

function keyPressed() {
  if (gameState === 'GAMEOVER') {
    // 랭킹 진입 가능하고 아직 이름을 입력하지 않은 경우
    let canEnterName = checkTopRank(score) && !isEnteringName;
    
    if (canEnterName) {
      // 이름 입력 모드
      if (keyCode === ENTER && playerName.trim() !== '') {
        saveScore();
      } else if (keyCode === BACKSPACE) {
        if (playerName.length > 0) {
          playerName = playerName.slice(0, -1);
        }
        return false; // 기본 동작 방지
      }
    } else {
      // 이름 입력이 끝났거나 랭킹 진입 실패 - 단축키 사용 가능
      if (key === 'r' || key === 'R') {
        restartGame();
      } else if (key === 'l' || key === 'L') {
        gameState = 'RANKING';
      }
    }
  } else if (gameState === 'RANKING') {
    if (key === 'r' || key === 'R') {
      restartGame();
    } else if (keyCode === ESCAPE) {
      gameState = 'PLAYING';
      restartGame();
    }
  }
}

function keyTyped() {
  if (gameState === 'GAMEOVER') {
    let canEnterName = checkTopRank(score) && !isEnteringName;
    
    if (canEnterName) {
      // 한국어 포함 모든 문자 입력 가능 (최대 10자)
      if (key && key !== 'Enter' && playerName.length < 10) {
        playerName += key;
        return false; // 기본 동작 방지
      }
    }
  }
}

function displayTimer() {
  push();
  
  // 타이머 배경
  let timerWidth = 180;
  let timerX = width - timerWidth - 10;
  
  // 그림자
  fill(0, 0, 0, 100);
  noStroke();
  rect(timerX + 5, 15, timerWidth, 60, 10);
  
  // 메인
  fill(255, 255, 255, 230);
  stroke(255, 0, 0);
  strokeWeight(4);
  rect(timerX, 10, timerWidth, 60, 10);
  
  // 시간에 따른 색상 변화
  let timeColor;
  if (remainingTime > 30) {
    timeColor = color(0, 255, 0);
  } else if (remainingTime > 10) {
    timeColor = color(255, 165, 0);
  } else {
    timeColor = color(255, 0, 0);
  }
  
  fill(50);
  noStroke();
  textSize(18);
  textAlign(LEFT, TOP);
  text('남은 시간', timerX + 15, 20);
  
  fill(timeColor);
  stroke(0);
  strokeWeight(2);
  textSize(35);
  text(Math.ceil(remainingTime) + 's', timerX + 15, 40);
  
  pop();
}

function onPoseNetReady() {
  poseNetReady = true;
  console.log('PoseNet 모델 로딩 완료!');
}

function onPoseResults(results) {
  poses = results;
}

function onHandposeReady() {
  handposeReady = true;
  console.log('Handpose 모델 로딩 완료!');
}

function onHandResults(results) {
  hands = results;
}

function checkPersonDetection() {
  if (poses.length > 0) {
    let pose = poses[0].pose;
    let confidenceCount = 0;
    for (let kp of pose.keypoints) {
      if (kp.score > 0.5) {
        confidenceCount++;
      }
    }
    personDetected = confidenceCount > 5;
  } else {
    personDetected = false;
  }
}

function spawnTrash() {
  let type = random(trashTypes);
  let trash = {
    x: random(50, width - 150),
    y: random(150, height - 100),
    size: 50,
    type: type,
    pickedUp: false,
    rotation: random(TWO_PI)
  };
  trashItems.push(trash);
}

function drawTrash() {
  for (let trash of trashItems) {
    if (trash.pickedUp && holdingTrash === trash) {
      trash.x = width - handPosition.x;
      trash.y = handPosition.y;
    }
    
    push();
    translate(trash.x, trash.y);
    rotate(trash.rotation);
    
    // 이미지가 있으면 이미지 사용
    if (trashImages[trash.type.name]) {
      imageMode(CENTER);
      image(trashImages[trash.type.name], 0, 0, trash.size, trash.size);
    } else {
      // 이미지가 없으면 커스텀 도형 그리기
      drawCustomTrash(trash.type.name, trash.size);
    }
    
    pop();
    
    // 들고 있는 쓰레기 표시
    if (trash.pickedUp) {
      noFill();
      stroke(255, 255, 0);
      strokeWeight(3);
      ellipse(trash.x, trash.y, trash.size + 15, trash.size + 15);
    }
  }
}

// 커스텀 쓰레기 그리기 함수
function drawCustomTrash(name, size) {
  switch(name) {
    case '페트병':
      drawBottle(size);
      break;
    case '캔':
      drawCan(size);
      break;
    case '종이':
      drawPaper(size);
      break;
    case '음식물':
      drawFood(size);
      break;
    case '병':
      drawGlassBottle(size);
      break;
  }
}

function drawBottle(size) {
  // 페트병 그리기
  fill(100, 200, 255, 180);
  stroke(50, 100, 200);
  strokeWeight(2);
  
  // 몸통
  rect(-size*0.25, -size*0.3, size*0.5, size*0.6, 5);
  
  // 뚜껑
  fill(200, 50, 50);
  rect(-size*0.15, -size*0.45, size*0.3, size*0.2, 3);
  
  // 라벨
  fill(255, 255, 255, 200);
  rect(-size*0.2, -size*0.1, size*0.4, size*0.2);
}

function drawCan(size) {
  // 캔 그리기
  fill(200, 200, 200);
  stroke(100);
  strokeWeight(2);
  
  // 몸통
  ellipse(0, 0, size*0.6, size*0.8);
  
  // 윗부분
  fill(150, 150, 150);
  ellipse(0, -size*0.3, size*0.6, size*0.2);
  
  // 당김 고리
  noFill();
  stroke(180);
  strokeWeight(3);
  ellipse(size*0.15, -size*0.3, size*0.15, size*0.15);
}

function drawPaper(size) {
  // 종이 그리기
  fill(255, 255, 230);
  stroke(200, 200, 180);
  strokeWeight(2);
  
  // 구겨진 종이
  beginShape();
  for (let i = 0; i < 8; i++) {
    let angle = i * TWO_PI / 8;
    let r = size * 0.4 + random(-5, 5);
    vertex(cos(angle) * r, sin(angle) * r);
  }
  endShape(CLOSE);
  
  // 선
  stroke(180);
  strokeWeight(1);
  for (let i = 0; i < 3; i++) {
    let y = -size*0.2 + i*size*0.2;
    line(-size*0.2, y, size*0.2, y);
  }
}

function drawFood(size) {
  // 음식물 그리기
  fill(255, 200, 100);
  stroke(200, 150, 50);
  strokeWeight(2);
  
  // 불규칙한 모양
  beginShape();
  for (let i = 0; i < 12; i++) {
    let angle = i * TWO_PI / 12;
    let r = size * (0.3 + random(0.1, 0.2));
    vertex(cos(angle) * r, sin(angle) * r);
  }
  endShape(CLOSE);
}

function drawGlassBottle(size) {
  // 유리병 그리기
  fill(150, 255, 150, 200);
  stroke(50, 150, 50);
  strokeWeight(2);
  
  // 몸통
  beginShape();
  vertex(-size*0.25, -size*0.4);
  vertex(-size*0.3, size*0.3);
  vertex(size*0.3, size*0.3);
  vertex(size*0.25, -size*0.4);
  endShape(CLOSE);
  
  // 목 부분
  fill(100, 200, 100, 200);
  rect(-size*0.15, -size*0.5, size*0.3, size*0.15);
  
  // 반짝임
  fill(255, 255, 255, 150);
  noStroke();
  ellipse(-size*0.15, -size*0.2, size*0.15, size*0.2);
}

function drawTrashBin() {
  push();
  translate(trashBin.x + trashBin.w/2, trashBin.y + trashBin.h/2);
  
  if (imageBin) {
    imageMode(CENTER);
    image(imageBin, 0, 0, trashBin.w, trashBin.h);
  } else {
    // 커스텀 쓰레기통 그리기
    drawCustomBin(trashBin.w, trashBin.h);
  }
  
  pop();
  
  // 라벨
  fill(255);
  stroke(0);
  strokeWeight(2);
  textSize(16);
  textAlign(CENTER, CENTER);
  text('쓰레기통', trashBin.x + trashBin.w/2, trashBin.y + trashBin.h + 20);
}

function drawCustomBin(w, h) {
  // 3D 쓰레기통
  
  // 그림자
  fill(0, 0, 0, 50);
  noStroke();
  ellipse(0, h/2 + 10, w*1.2, 20);
  
  // 앞면
  fill(100, 100, 100);
  stroke(50);
  strokeWeight(3);
  rect(-w/2, -h/2, w, h, 10);
  
  // 측면 (3D 효과)
  fill(80, 80, 80);
  beginShape();
  vertex(-w/2, -h/2);
  vertex(-w/2 + 10, -h/2 - 10);
  vertex(w/2 + 10, -h/2 - 10);
  vertex(w/2, -h/2);
  endShape(CLOSE);
  
  // 뚜껑
  fill(120, 120, 120);
  rect(-w/2 - 5, -h/2 - 15, w + 10, 15, 5);
  
  // 손잡이
  noFill();
  stroke(90);
  strokeWeight(4);
  arc(0, -h/2 - 15, w*0.4, 20, PI, TWO_PI);
  
  // 재활용 마크
  fill(255);
  noStroke();
  textSize(h * 0.5);
  textAlign(CENTER, CENTER);
  text('♻️', 0, 0);
}

function drawHands() {
  if (hands.length > 0) {
    for (let hand of hands) {
      let landmarks = hand.landmarks;
      
      let palmX = 0, palmY = 0;
      for (let i = 0; i < landmarks.length; i++) {
        palmX += landmarks[i][0];
        palmY += landmarks[i][1];
      }
      palmX /= landmarks.length;
      palmY /= landmarks.length;
      
      handPosition.x = palmX;
      handPosition.y = palmY;
      
      // 손가락 랜드마크 - 더 멋진 스타일
      for (let i = 0; i < landmarks.length; i++) {
        fill(255, 100, 100, 150);
        stroke(255, 50, 50);
        strokeWeight(2);
        ellipse(width - landmarks[i][0], landmarks[i][1], 10, 10);
      }
      
      // 손바닥 중심 - 빛나는 효과
      for (let r = 30; r > 0; r -= 10) {
        fill(0, 255, 0, 50);
        noStroke();
        ellipse(width - palmX, palmY, r, r);
      }
      fill(0, 255, 0);
      stroke(255);
      strokeWeight(3);
      ellipse(width - palmX, palmY, 20, 20);
    }
  }
}

function detectGrabAction() {
  if (hands.length > 0) {
    let hand = hands[0];
    let annotations = hand.annotations;
    
    if (annotations && annotations.thumb && annotations.indexFinger) {
      let thumbTip = annotations.thumb[3];
      let indexTip = annotations.indexFinger[3];
      let distance = dist(thumbTip[0], thumbTip[1], indexTip[0], indexTip[1]);
      
      let handX = width - handPosition.x;
      let handY = handPosition.y;
      
      if (distance < 40 && !isGrabbing) {
        isGrabbing = true;
        
        if (!holdingTrash) {
          for (let trash of trashItems) {
            if (!trash.pickedUp) {
              let d = dist(handX, handY, trash.x, trash.y);
              if (d < trash.size) {
                trash.pickedUp = true;
                holdingTrash = trash;
                console.log('쓰레기 집음!');
                break;
              }
            }
          }
        }
      } 
      else if (distance > 80 && isGrabbing) {
        isGrabbing = false;
        
        if (holdingTrash) {
          let d = dist(handX, handY, trashBin.x + trashBin.w/2, trashBin.y + trashBin.h/2);
          
          if (d < 100) {
            score += holdingTrash.type.points;
            console.log('점수 획득! +' + holdingTrash.type.points);
            
            let index = trashItems.indexOf(holdingTrash);
            if (index > -1) {
              trashItems.splice(index, 1);
            }
            
            spawnTrash();
            showSuccessEffect();
          } else {
            holdingTrash.pickedUp = false;
            console.log('쓰레기통에 버려주세요!');
          }
          
          holdingTrash = null;
        }
      }
    }
  }
}

function showSuccessEffect() {
  successEffectTimer = 60;
  
  // 파티클 생성
  for (let i = 0; i < 20; i++) {
    successParticles.push({
      x: trashBin.x + trashBin.w/2,
      y: trashBin.y + trashBin.h/2,
      vx: random(-5, 5),
      vy: random(-8, -3),
      life: 60,
      size: random(5, 15),
      color: [random(100, 255), random(100, 255), random(100, 255)]
    });
  }
}

function displayScore() {
  // 점수판 - 더 멋진 디자인
  push();
  
  // 그림자
  fill(0, 0, 0, 100);
  noStroke();
  rect(15, 15, 200, 80, 10);
  
  // 메인
  fill(255, 255, 255, 230);
  stroke(255, 200, 0);
  strokeWeight(4);
  rect(10, 10, 200, 80, 10);
  
  // 그라데이션 효과
  for (let i = 0; i < 80; i++) {
    let alpha = map(i, 0, 80, 50, 0);
    stroke(255, 200, 0, alpha);
    strokeWeight(1);
    line(10, 10 + i, 210, 10 + i);
  }
  
  fill(50);
  noStroke();
  textSize(20);
  textAlign(LEFT, TOP);
  text('점수', 25, 25);
  
  textSize(40);
  fill(255, 165, 0);
  stroke(255, 255, 0);
  strokeWeight(2);
  text(score, 25, 50);
  
  pop();
  
  // 성공 효과
  if (successEffectTimer > 0) {
    fill(0, 255, 0, successEffectTimer * 4);
    noStroke();
    textSize(80);
    textAlign(CENTER, CENTER);
    text('✓', width/2, height/2);
    
    textSize(40);
    fill(255, 255, 0, successEffectTimer * 4);
    text('성공!', width/2, height/2 + 60);
    
    successEffectTimer--;
  }
  
  // 파티클 효과
  for (let i = successParticles.length - 1; i >= 0; i--) {
    let p = successParticles[i];
    
    fill(p.color[0], p.color[1], p.color[2], map(p.life, 0, 60, 0, 255));
    noStroke();
    ellipse(p.x, p.y, p.size, p.size);
    
    p.x += p.vx;
    p.y += p.vy;
    p.vy += 0.3; // 중력
    p.life--;
    
    if (p.life <= 0) {
      successParticles.splice(i, 1);
    }
  }
}

function displayInstructions() {
  fill(255, 255, 255, 200);
  stroke(0);
  strokeWeight(3);
  textSize(20);
  textAlign(CENTER, BOTTOM);
  
  let instructionText = holdingTrash ? '쓰레기통 근처에서 손을 펴서 버리세요!' : '쓰레기 위에서 손을 쥐어 집으세요!';
  let bgWidth = textWidth(instructionText) + 40;
  
  fill(0, 0, 0, 150);
  noStroke();
  rect(width/2 - bgWidth/2, height - 50, bgWidth, 40, 10);
  
  fill(255);
  stroke(0);
  strokeWeight(2);
  text(instructionText, width/2, height - 20);
}

function displayDebugInfo() {
  fill(0, 0, 0, 150);
  noStroke();
  rect(10, 100, 250, 140, 5);
  
  fill(255);
  textSize(14);
  textAlign(LEFT, TOP);
  text(`사람 감지: ${personDetected ? '예' : '아니오'}`, 20, 110);
  text(`손 감지: ${hands.length}개`, 20, 130);
  text(`손 상태: ${isGrabbing ? '쥐고 있음' : '펴져 있음'}`, 20, 150);
  text(`들고 있는 쓰레기: ${holdingTrash ? holdingTrash.type.name : '없음'}`, 20, 170);
  text(`쓰레기 개수: ${trashItems.length}개`, 20, 190);
  text(`FPS: ${frameRate().toFixed(0)}`, 20, 210);
}